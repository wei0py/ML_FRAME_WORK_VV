1. generate features as usual, and run linear fitting first
2. go to fitModelDir, and in this directory, run covariance.r 
   for example, in fitModelDir, run `/home/buyu/MLFF/Cov_test/test_codes/covariance.r`
3. run md using `lin`, the codedir should be the workdir in Cov_test
4. you can use the genFeatDir as the one you used before.